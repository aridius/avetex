<?php
// HTTP
define('HTTP_SERVER', 'http://avetex.aridius.com/admin/');
define('HTTP_CATALOG', 'http://avetex.aridius.com/');

// HTTPS
define('HTTPS_SERVER', 'http://avetex.aridius.com/admin/');
define('HTTPS_CATALOG', 'http://avetex.aridius.com/');

// DIR
define('DIR_APPLICATION', '/home/leomeb01/aridius.com/avetex/admin/');
define('DIR_SYSTEM', '/home/leomeb01/aridius.com/avetex/system/');
define('DIR_IMAGE', '/home/leomeb01/aridius.com/avetex/image/');
define('DIR_STORAGE', '/home/leomeb01/aridius.com/storage_avetex/');
define('DIR_CATALOG', '/home/leomeb01/aridius.com/avetex/catalog/');
define('DIR_LANGUAGE', DIR_APPLICATION . 'language/');
define('DIR_TEMPLATE', DIR_APPLICATION . 'view/template/');
define('DIR_CONFIG', DIR_SYSTEM . 'config/');
define('DIR_CACHE', DIR_STORAGE . 'cache/');
define('DIR_DOWNLOAD', DIR_STORAGE . 'download/');
define('DIR_LOGS', DIR_STORAGE . 'logs/');
define('DIR_MODIFICATION', DIR_STORAGE . 'modification/');
define('DIR_SESSION', DIR_STORAGE . 'session/');
define('DIR_UPLOAD', DIR_STORAGE . 'upload/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'leomeb01.mysql.tools');
define('DB_USERNAME', 'leomeb01_avetex');
define('DB_PASSWORD', '#8-CGe4mv9');
define('DB_DATABASE', 'leomeb01_avetex');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');

// OpenCart API
define('OPENCART_SERVER', 'https://www.opencart.com/');
define('OPENCARTFORUM_SERVER', 'https://opencartforum.com/');
