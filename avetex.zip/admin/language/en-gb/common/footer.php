<?php
// Text
$_['text_footer']  = '<a href="https://ocstore.com/?utm_source=ocstore3_install">ocStore</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Version %s<br/>Best performance <a target="_blank" href="https://turbohost.pro/?utm_source=ocstore23">TurboHost.pro</a>';