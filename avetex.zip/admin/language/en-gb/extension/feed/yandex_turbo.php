<?php
// Heading
$_['heading_title']   = 'Yandex Turbo';

// Text
$_['text_extension']  = 'Extensions';
$_['text_success']    = 'Success: You have modified Yandex Turbo feed!';
$_['text_edit']       = 'Edit Yandex Turbo';

// Entry
$_['entry_status']    = 'Status';
$_['entry_currency']  = 'Currency';
$_['entry_made']      = 'Made by <a href="https://opencartforum.com/profile/678128-spectre/" target="_blank">@spectre</a>';
$_['entry_data_feed'] = 'Data Feed Url';

// Error
$_['error_permission']= 'Warning: You do not have permission to modify Yandex Turbo feed!';