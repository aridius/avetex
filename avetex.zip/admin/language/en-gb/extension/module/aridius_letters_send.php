<?php
// Heading 
$_['heading_title']              = 'Editing newsletter';
