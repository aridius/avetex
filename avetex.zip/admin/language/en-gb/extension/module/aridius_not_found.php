<?php
// Heading
$_['heading_title']          = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Page 404</strong>';

// Text
$_['text_edit']            	 = 'Edit';
$_['text_message']           = 'Form';
$_['entry_status']           = 'Status';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify FAQ module!';
$_['error_name']             = 'Module Name must be between 3 and 64 characters!';



