<?php
$_['heading_title']             = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Home page text</strong>';

// Text
$_['text_module']               = 'Modules';
$_['text_success']              = 'Success: You have modified bestsellers (carousel) module!';
$_['text_edit']                 = 'Edit';
$_['text_extension']            = 'Extensions';
$_['text_description']          = 'Text';
$_['text_footer_limit']         = 'Show button "Show all" by symbol number more';
$_['text_footer_limit_height']  = 'Block and description text height (pixels)';
$_['entry_status']              = 'Status';
$_['text_extension']            = 'Extensions';
$_['button_apply']              = 'Apply';

// Error
$_['error_permission']          = 'Warning: You do not have permission to modify bestsellers (carousel) module!';
$_['error_name']                = 'Module Name must be between 3 and 64 characters!';

