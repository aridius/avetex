<?php
$_['heading_title']          = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Cookie</strong>';
$_['text_edit']              = 'Edit';

// Text
$_['text_module']            = 'Modules';
$_['text_success']           = 'Success: You have modified live search module!';
$_['text_edit']            	 = 'Edit';
$_['entry_name']             = 'Module Name';
$_['entry_status']           = 'Status';
$_['button_save']            = 'Save';
$_['button_cancel']          = 'Cancel';
$_['entry_description_top']  = 'Text';
$_['text_extension']         = 'Extensions';
$_['button_apply']           = 'Apply';
$_['entry_color']            = 'Color';
$_['entry_back']             = 'Background';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify FAQ module!';
$_['error_name']             = 'Module Name must be between 3 and 64 characters!';