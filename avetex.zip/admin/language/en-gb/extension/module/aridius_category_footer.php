<?php
// Heading
$_['heading_title']          = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Categories footer</strong>';

// Text
$_['text_module']     	 	 = 'Modules';
$_['text_success']			 = 'Success: You have modified categories(accordion) module!';
$_['text_edit']       		 = 'Edit';
$_['text_all'] 	 			 = 'Select All Categories';
$_['text_dell'] 			 = 'Unselect All Categories';
$_['text_categoryaccord'] 	 = 'Select which categories to display';
$_['text_extension']         = 'Extensions';

// Entry
$_['entry_status']           = 'Status';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify categories(accordion) module!';