<?php

// Heading
$_['tab_custom_tab']               = 'Custom Tabs';

// Text
$_['text_name_top_add_tabs']       = 'Tab Title';
$_['text_description']             = 'Description';
$_['text_sort']                    = 'Sort Order';
$_['text_add_custom_tab']          = 'Add Custom Tabs';
$_['tab_custom_tab_link']          = 'Tab';