<?php
$_['heading_title']          = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Information block in the product card</strong>';
$_['text_edit']              = 'Edit';

// Text
$_['text_module']            = 'Modules';
$_['text_success']           = 'Success: You have modified FAQ module!';
$_['text_edit']            	 = 'Edit';

$_['entry_status']           = 'Status';
$_['button_save']            = 'Save';
$_['button_cancel']          = 'Cancel';
$_['tab_top_link']           = 'Tab';
$_['text_add_top_link']      = 'Add Tab';
$_['text_name_top_add_tabs'] = 'Tab Title';

$_['text_link_top']          = 'Text';

$_['text_faicons_faq']       = 'Icon';
$_['entry_meta_title']       = 'Meta Tag Title';

$_['text_extension']         = 'Extensions';
$_['button_apply']           = 'Аpply';
// Error
$_['error_permission']       = 'Warning: You do not have permission to modify FAQ module!';
$_['error_name']             = 'Module Name must be between 3 and 64 characters!';