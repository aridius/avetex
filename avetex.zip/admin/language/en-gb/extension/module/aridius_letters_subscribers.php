<?php
// Heading 
$_['heading_title']              = 'Editing Newsletter Subscribers';
