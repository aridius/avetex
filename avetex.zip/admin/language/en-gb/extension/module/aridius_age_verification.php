<?php
$_['heading_title']          = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">18+</strong>';
$_['text_edit']              = 'Edit';

// Text
$_['text_module']            = 'Modules';
$_['text_success']           = 'Success: You have modified popup text module!';
$_['entry_status']           = 'Status';
$_['button_save']            = 'Save';
$_['button_cancel']          = 'Cancel';
$_['entry_description_top']  = 'Text';
$_['entry_description_top2'] = 'Text when push on the "no" button';
$_['entry_name']             = 'Module Name';
$_['text_extension']         = 'Extensions';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify popup text module!';
$_['error_name']             = 'Module Name must be between 3 and 64 characters!';



