<?php
// Heading
$_['heading_title']   	 = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Mobile menu button</strong>';

// Text
$_['text_module']     	 = 'Modules';
$_['text_success']    	 = 'Success: You have modified category wall module!';
$_['text_edit']       	 = 'Edit';
$_['entry_width']     	 = 'Width';
$_['entry_height']    	 = 'Height';
$_['text_all']        	 = 'Select All Categories';
$_['text_dell']       	 = 'Unselect All Categories';
$_['text_extension']  	 = 'Extensions';

// Entry
$_['entry_status']    	 = 'Status';
$_['entry_name']       	 = 'Module Name';


