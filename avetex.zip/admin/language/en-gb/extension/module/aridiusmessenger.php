<?php
// Heading
$_['heading_title']          = 'Aridius (Deluxe) &nbsp;<strong style = "color: #4174CD;">Messenger widget</strong>';

// Text
$_['text_edit']            	 = 'Edit';
$_['text_legend']            = 'Create messenger widget';
$_['tab_top_link']           = 'Tab';
$_['text_add_top_link']      = 'Add icon';
$_['text_name_top_add_tabs'] = 'Widget name';
$_['text_name_call']         = 'Сall order Button Text';
$_['text_faicons_icons']     = 'Link';
$_['text_link_top']          = 'Icon';
$_['text_mailstatus']        = 'Display Call Back';
$_['text_link_top_main']     = 'Main icon widget';
$_['entry_status']           = 'Status';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify module!';
$_['error_name']             = 'Module Name must be between 3 and 64 characters!';



